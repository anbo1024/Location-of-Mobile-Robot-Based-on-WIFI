#ifndef TTHERSDIALOG_H
#define TTHERSDIALOG_H

#include <QDialog>

namespace Ui {
class tthersDialog;
}



#endif // TTHERSDIALOG_H
