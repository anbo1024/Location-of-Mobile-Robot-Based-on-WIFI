#include "mmanipulatorcontroler.h"

mManipulatorControler::mManipulatorControler(QObject *parent)
    : QObject(parent)
{

}
