#ifndef CHILEDIALOG_H
#define CHILEDIALOG_H

#include <QWidget>

namespace Ui {
class chileDialog;
}



#endif // CHILEDIALOG_H
