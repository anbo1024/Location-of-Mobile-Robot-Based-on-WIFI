#ifndef MANPUDIALOG_H
#define MANPUDIALOG_H

#include <QDialog>
#include "mainwindow.h"





#endif // MANPUDIALOG_H
